<?php 

/* Template name: Portfolio */


get_header(); 

echo woodmart_shortcode_portfolio( array( 'portfolio_location' => 'page' ) );

get_footer(); ?>