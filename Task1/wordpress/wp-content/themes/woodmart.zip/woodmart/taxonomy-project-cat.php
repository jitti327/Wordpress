<?php
/**
 * The template for displaying portfolio category Archive page
 *
 */

get_template_part( 'portfolio' );