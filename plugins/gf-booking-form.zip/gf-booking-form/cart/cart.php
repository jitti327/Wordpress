<?php
  if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

  $fieldArray = $this->fieldIds['front'];
  $fieldValues = [];


  foreach($fieldArray as $key => $value ){

    if(!empty( $_POST["input_".$value] ) ){
       $fieldValues[$key] = $_POST["input_".$value];
    }
  }

  $hideCss = "display:none;";

  extract($fieldValues);


  $priceArray = [
    'cndScr'   => 'Condition Sun Screens',
    'cngFan'   => 'Ceiling Fans',
    'bldShtr'  => 'Blinds / Shutters',
    'pwWash'   => 'Power Wash (1 hour)',
    'gtClean'  => 'Gutter Cleaning',
  ];

  $fieldMatch = [
    'cndScr'   => 'condSunScPr' ,
    'cngFan'   => 'clngFanPr',
    'bldShtr'  => 'blndShutrPr',
    'pwWash'   => 'pwrWashPr',
    'gtClean'  => 'gtrCleanPr',
  ];
?>


<div class="cart-side">

  <div class="form-title--side">
    <h2 class="card-side__title"><strong>Booking Summary</strong></h2>
    <a class="btn-round" href="#">First Service</a>
  </div>

  <div class="main-side">

    <div class="card-side">
      <img class="card-side__img" src="http://gf.incredible-developers.com/wp-content/uploads/2019/05/summary1.png" alt="window" />
      <div class="card-side__content">
        <div class="descr">
          <p class="descr__gray">Window Cleaning (Exterior)</p>
          <p class="descr__price"><strong>$ 99.90</strong></p>
        </div>
      </div>
    </div>

    <?php //if(isset($dateTime)){ ?>
    <div class="card-side">
      <img class="card-side__img" src="http://gf.incredible-developers.com/wp-content/uploads/2019/05/summary2-date.png" alt="calander" />
      <div class="card-side__content">
        <div class="descr">
          <p class="descr__gray">Friday, 24 May, 2019</p>
          <!-- <p class="descr__price"><strong>$ 69.90</strong></p> -->
        </div>
      </div>
    </div>
    <?php //} ?>

    <section class="price">
      <div class="descr">
        <p class="descr__small">Recurring Service</p>
        <b>Bi-Weekly</b>
        <div class="descr__img"><img style="width: 25px;" src="http://gf.incredible-developers.com/wp-content/uploads/2019/05/summary3.png" />
        </div>
      </div>
      <div class="descr">
        <p class="descr__gray">Subtotal</p>
        <p class="descr__price">$ 169.80</p>
      </div>
      <div class="ids-addon">

        <h2><b>Add-Ons Total</b></h2>
        <?php foreach($priceArray as $key => $value){


          $hideText = $hideCss;
          $price    = "";
          if(isset(${$fieldMatch[$key]})){
          $hideText = "";
          $price = ${$fieldMatch[$key]};
          }
          $pValue = str_replace($this->currency, "", $price);

          echo $pValue;
          if(empty($pValue) || $pValue == 0.0){
          $hideText = $hideCss;
          }
          ?>
             <div class="descr <?php echo $key; ?>-cont" style="<?php echo $hideText; ?>" >
              <p class="descr__gray"> <?php echo $value; ?></p>
              <p class="descr__price">+ <?php if(isset($currencySymbol)){ echo $currencySymbol .''. $pValue; } ?></p>
            </div>
        <?php } ?>
        <!--<div class="descr">
          <p class="descr__gray">
          Condition Sun Screens</p>
          <p class="descr__price">+ $5/screen</p>
        </div>

        <div class="descr">
          <p class="descr__gray">
          Ceiling Fans</p>
          <p class="descr__price">+ $9/fan</p>
        </div>

        <div class="descr">
          <p class="descr__gray">
          Blinds / Shutters</p>
          <p class="descr__price">+ $9/blind</p>
        </div>-->
      </div>

      <div class="descr">
        <p class="descr__small"><b>Total Estimate</b></p>
        <p class="descr__price"><strong>$ 169.80</strong></p>
      </div>

    </section>

  </div>

</div>