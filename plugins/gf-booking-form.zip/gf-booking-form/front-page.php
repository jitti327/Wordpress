<?php


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly 

class windCleaner {

  private $pluginUrl;
  private $pluginPath;
  private $version;
  private $debug    = true;
  private $currency = '$';
  public  $messages = [
    'empty' => "Please Select..."
  ];
 

  public $formIds = [
    'front'       => '1',
  ];
  public $fieldIds = [
    'front'          => [
      'frqOfService'    => "16",
      "dateTime"        => "26",
      'addOnServices'   => "29",
      'winClnPkg'       => "63",
      'condSunScPr'     => "70",
      'clngFanPr'       => "72",
      'blndShutrPr'     => "73",
      'pwrWashPr'       => "74",
      'gtrCleanPr'      => "74",
    ]
  ];


  public function __construct ($obj) {

    $this->pluginUrl   = plugin_dir_url( __FILE__ );
    $this->pluginPath  = plugin_dir_path( __FILE__ );

    if($this->debug === true){
      ini_set('display_startup_errors', 1);
      ini_set('display_errors', 1);
      error_reporting(-1);
    }

    #$this->formIds     = $obj->pluginUrl;
    ##Added Cart Page HTML Shortcode.
    add_shortcode('render-cart-html', [$this, 'cartHtml']);

    ##Add Script For Cart.
    add_action('wp_enqueue_scripts', [$this, 'cartApiScripts']); 
    
  }

  public function cartHtml(){
    ob_start();
    include $this->pluginPath . 'cart/cart.php';
    return ob_get_clean();
  }

  public function cartApiScripts(){

    $jsPath = 'js/cleaner.js';
    $jsVer  = date("ymd-Gis", filemtime( $this->pluginPath . $jsPath ));
    $jsUrl  = $this->pluginUrl . $jsPath;

    wp_enqueue_script('ids-cleaner-js', $jsUrl, ['jquery'], $jsVer, true);

    $ajaxObj = [
      'ajax_url'   => admin_url( 'admin-ajax.php' ),
      'field_ids'  => $this->fieldIds['front'],
      'form_id'    => $this->formIds['front'],
      'messages'   => $this->messages,
    ];

    wp_localize_script( 'ids-cleaner-js', 'cleanerObj', $ajaxObj );
  }
}



function debug($param){
  echo '<pre>';
  print_r($param);
  echo '</pre>';
}

