<?php
  function insertPackage($table,$data=[]){
  	global $wpdb;
	  if(empty($table)){
      return false;
	  }
		$insert = $wpdb->insert($table, $data);	 
		return $insert; 
  } 

  function message_notification($status='',$text=""){
    add_settings_error( 'settings-page-slug', 'error_code', $text,$status );
  }

  function DeleteAction( $tableName , $id=[] , $type=['%d']){
    global $wpdb;
    $table = $tableName;
    $deleteQuery = $wpdb->delete($table , $id, $type);
    return $deleteQuery;                 
  } 

  function fatchSingleRecord($table , $where=""){
  	global $wpdb;
	  if(empty($table)){
      return false;
	  }  	
  	$query = "SELECT * FROM `".$table."` WHERE $where";
  	$fatchQuery = $wpdb->get_results($query);
  	return $fatchQuery;
  } 

  function countRecord($table , $where=""){
    global $wpdb;
    if(empty($table)){
      return false;
    }   
    $fatchQuery = $wpdb->get_results("SELECT * FROM `".$table."` WHERE $where");
    return $wpdb->num_rows;;
  }   

  function updatePackage($table,$row=[],$id=[]){
    global $wpdb;
    if(empty($table)){
      return false;
    }      
    $update = $wpdb->update($table , $row , $id ,array('%s'));
    return $update;
  } 

  function allFatchRecord($tableName){
    global $wpdb;
    if(empty($tableName)){
      return false;
    }      
    $fatchQuery = $wpdb->get_results(" SELECT * FROM `".$tableName."`");
    return $fatchQuery;
  }
?>