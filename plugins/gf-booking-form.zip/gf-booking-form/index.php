<?php
/*
Plugin Name: GF Booking System
Plugin URI: 
Description: GF Booking System
Author: Vivek.
Version: 1.0
Author URI:
*/
include_once('init.php');

class jolleyBookingForm{

  private $pluginUrl;
  private $pluginPath;
  private $version;

 public function __construct(){

  $this->pluginUrl   = plugin_dir_url( __FILE__ );
  $this->pluginPath  = plugin_dir_path( __FILE__ );
  $this->version     = '1.0.0';

  ## Plugin Activation Hook
  register_activation_hook( __FILE__   , array( $this,'RQ_Activation' )   );
  ## Plugin Deactivation Hook
  register_deactivation_hook( __FILE__ , array( $this,'RQ_Deactivation' ) );
  #########################
  add_action( 'wp_enqueue_scripts', array( $this,  'jolleyScripts' ) ); 
  ##############
  add_action( 'admin_enqueue_scripts', array( $this,  'adminJolleyScripts' ) );   
  ##############
  add_action( 'admin_menu' , array( $this, 'addPluginPage' ) );
  add_action( 'admin_init' , array( $this, 'page_package' ) );
  add_action( 'admin_init' , array( $this, 'package_options_page' ) );      

  ################################
  add_shortcode( 'jolley-pricing-table', array( $this, 'renderTableHTML') );

  /*
  ** Added new class for front page
  */
  include_once $this->pluginPath . 'front-page.php';
  new windCleaner( $this );
 }


  ######################
  public function renderTableHTML(){
    ob_start();
    global $wpdb;
    $packages      = $wpdb->prefix.PACKAGE; 
    $packageOption = $wpdb->prefix.PACKAGEOPTION;      
    $metaPO        = $wpdb->prefix.META_PO;    
    
    $packages = allFatchRecord($packages);
    $pOption  = allFatchRecord($packageOption);
    $array = array(
      "packages" => array( $packages  ),
      "options" => array( $pOption ),

    );
    include("table.php");
    return ob_get_clean();
  }


  ##################
  public function jolleyScripts(){
      
    wp_enqueue_style( 'custom-css',  plugin_dir_url(__FILE__) . 'css/style.css?'.time() );
    wp_enqueue_style( 'custom-style-css',  plugin_dir_url(__FILE__) . 'css/custom.css?'.time() );
    wp_enqueue_script('nomads-js', $this->pluginUrl . 'js/nomads.js', ['jquery'], $this->version, true);
    wp_enqueue_script('gf-stickey', $this->pluginUrl . 'js/sticky-kit.js', ['jquery'], $this->version, true);
  }

  ##################
  public function adminJolleyScripts(){
    wp_enqueue_style( 'custom-css',  plugin_dir_url(__FILE__) . 'css/style.css?'.time() );
    wp_enqueue_style( 'custom-style-css',  plugin_dir_url(__FILE__) . 'css/custom.css?'.time() );
    wp_enqueue_script( 'custom-js'  , plugin_dir_url(__FILE__) . 'js/custom.js'   );
  }

  ## Plugin Activation Callback
  public function RQ_Activation(){
    //wp_die( "Plugin has been activated" );
  }

  ## Plugin Deactivation Callback
  public function RQ_Deactivation(){
    //wp_die( "Plugin has been deactivated" );
  }

  ############################
  public function addPluginPage(){
    add_menu_page(
      'Jolley Pricing Table',              // page_title
      'Jolley Pricing Table',              // menu_title
      'manage_options',                    // Capability
      'jolley_pricing',                    // Slug
      array( $this, 'viewPackages' ),      // Function Name
      'dashicons-admin-generic'            // Used For Icon
    );  

    add_submenu_page(                    
      'jolley_pricing',                     // parent menu slug
      'Jolley Packages',                    // title name
      'Packages',                           // shortcode reference
      'manage_options',                     // Capability (who can use this option)
      'list-package',                       // slug (unique of key)
      array( $this, 'viewPackages' )        // function(call back)
    ); 

    add_submenu_page(                    
      'jolley_pricing_hide',                // parent menu slug
      'Edit Package',                       // title name
      'Packages',                           // shortcode reference
      'manage_options',                     // Capability (who can use this option)
      'edit-package',                       // slug (unique of key)
      array( $this, 'editPackage' )         // function(call back)
    ); 

    add_submenu_page(                    
      'jolley_pricing_hide',                // parent menu slug
      'Add Package',                        // title name
      'Packages',                           // shortcode reference
      'manage_options',                     // Capability (who can use this option)
      'add-package',                        // slug (unique of key)
      array( $this, 'addPackage' )          // function(call back)
    ); 


    add_submenu_page(                    
      'jolley_pricing',                     // parent menu slug
      'Jolley Pricing Table',               // title name
      'Package Options',                    // shortcode reference
      'manage_options',                     // Capability (who can use this option)
      'package_options',                    // slug (unique of key)
      array( $this, 'viewOptions' )         // function(call back)
    ); 

    add_submenu_page(                    
      'jolley_pricing_hide',                // parent menu slug
      'Add Package',                        // title name
      'Add Package Option',                 // shortcode reference
      'manage_options',                     // Capability (who can use this option)
      'add-packageOption',                  // slug (unique of key)
      array( $this, 'addPackageOption' )    // function(call back)
    );   

    add_submenu_page(                    
      'jolley_pricing_hide',                // parent menu slug
      'Add Package',                        // title name
      'Edit Package Option',                // shortcode reference
      'manage_options',                     // Capability (who can use this option)
      'edit-packageOption',                 // slug (unique of key)
      array( $this, 'editPackageOption' )   // function(call back)
    );                     

    remove_submenu_page('jolley_pricing','jolley_pricing');
  }  

  public function page_package(){
   
   // Insert Package
    add_settings_section(
      'package_id',                         // ID
      '',                                   // Title
      '',                                   // Callback
      'my-setting-admin'                    // Page
    );             

    add_settings_field(
        'package_ID',                        // ID
        'Package Name',                      // Title 
        array( $this, 'textField' ),         // Callback
        'my-setting-admin',                  // Page
        'package_id'                         // Section           
    );   
  
  // update package and insert the package options
    add_settings_section(
      'packageUpdate_id',                   // ID
      '',                                   // Title
      '',                                   // Callback
      'package-update'                      // Page
    );  
    add_settings_field(
        'packageText_ID',                    // ID
        'Package Name',                      // Title 
        array( $this, 'textField' ),         // Callback
        'package-update',                    // Page
        'packageUpdate_id'                   // Section           
    );  
    add_settings_field(
        'packageSelect_ID',                  // ID
        'Package Options',                   // Title 
        array( $this, 'textCheckboxField' ), // Callback
        'package-update',                    // Page
        'packageUpdate_id'                   // Section           
    );                                   
  }

  public function package_options_page(){
    add_settings_section(
      'option_field_id',                     // ID
      '',                                    // Title
      '',                                    // Callback
      'package-option-setting'               // Page
    );       

    add_settings_field(
        'option_ID',                         // ID
        'Package Option Name',               // Title 
        array( $this, 'textField' ),         // Callback
        'package-option-setting',            // Page
        'option_field_id'                    // Section           
    );
    add_settings_field(
        'text_option_ID',                    // ID
        'Type',                              // Title 
        array( $this, 'dorpDown' ),          // Callback
        'package-option-setting',            // Page
        'option_field_id'                    // Section           
    );    
  }  

  /** 
   * Get the settings option array and print one of its values
   */
  public function textField(){
    $value = "";
    if(isset($_REQUEST['post'])){
      global $wpdb;
      $tableName = $wpdb->prefix.PACKAGE;
      if($_REQUEST['page'] == 'edit-packageOption'){
        $tableName = $wpdb->prefix.PACKAGEOPTION;
      }  
      $record  = fatchSingleRecord($tableName , '`id`='.$_REQUEST['post']);
      $value   = empty($record[0]->package_name) ? '' : $record[0]->package_name;
      if($_REQUEST['page'] == 'edit-packageOption'){
        $value  = empty($record[0]->package_option_name) ? '' : $record[0]->package_option_name;
      }
    }
    echo '<input type="text" name="package_name" value="'.$value.'" required/>';
  }

  #####
  public function textCheckboxField(){   
    global $wpdb;
    $packageOption = $wpdb->prefix.PACKAGEOPTION;      
    $metaPO        = $wpdb->prefix.META_PO;      
    $fatchQuery = allFatchRecord($packageOption);
    if(empty($fatchQuery)){
      $fatchQuery = [];
    } 

    $fatchMetaQuery = fatchSingleRecord($metaPO, '`package_id`='.$_REQUEST['post']);

    $checkedOptionID = [];
    $textField       = [];
    foreach ($fatchMetaQuery as $metaValue) {
      $checkedOptionID[] = $metaValue->package_option_id;
      if($metaValue->package_option_key == 'yes'){
        continue;
      }
      $textField[$metaValue->package_option_id] = $metaValue->package_option_key;
    }    
    foreach ($fatchQuery as $packageoption) {

      if($packageoption->type == 'text'){
        echo '<div class="packageoptionField">'.$packageoption->package_option_name.
        '<input type="text" class="optionField" name="package_option_key['.$packageoption->id.']" value="'.$textField[$packageoption->id].'" ></div><br>';
      }

      if($packageoption->type == 'checkbox' || $packageoption->type == ''){
        $check = "";
        if( in_array($packageoption->id, $checkedOptionID) ){
          $check = 'checked="checked"';
        }       
        echo '<div class="packageoptionField"><input type="checkbox" name="package_option_name[]" value="'.$packageoption->id.'" '.$check.'>'.$packageoption->package_option_name.'</div><br>'; 
      } 

    }
  }

  #########
  public function dorpDown(){
    global $wpdb;
    $packageOption = $wpdb->prefix.PACKAGEOPTION;  
    $fatchQuery = fatchSingleRecord($packageOption, '`id`='.$_REQUEST['post']);
    $typeField = ['text'=>'Text','checkbox'=>'Checkbox'];
    echo  '<select name="type">
             <option value="">Select Type</option>
          ';
            foreach ($typeField as $key => $value) {
              $checked = ($fatchQuery[0]->type == $key) ? 'selected="selected"' : '';
              echo "<option value='".$key."' $checked>$value</option>";
            }
    echo  '</select>';
  }

  ##########
   public function editPackage(){
       global $wpdb;
      $packageTable  = $wpdb->prefix.PACKAGE;      
      $packageOption = $wpdb->prefix.PACKAGEOPTION;      
      $metaPO        = $wpdb->prefix.META_PO;      
      include_once('template-part/package/update.php');
   }
  
  ##########
   public function addPackage(){
      global $wpdb;
      $tableName = $wpdb->prefix.PACKAGE;
      include_once('template-part/package/add.php');
   }

  ##########
  public function viewPackages(){
    include_once('template-part/package/crud/list.php');
    include_once('template-part/package/listing.php');
  }

  public function addPackageOption(){
    global $wpdb;
    $tableName = $wpdb->prefix.PACKAGEOPTION;
    include_once('template-part/package_option/add.php'); 
  }

  public function editPackageOption(){
    global $wpdb;
    $packageOption = $wpdb->prefix.PACKAGEOPTION; 
    include_once('template-part/package_option/update.php');
  }  
  

  ###########
  public function viewOptions(){
    include_once('template-part/package_option/crud/list.php');
    include_once('template-part/package_option/listing.php');
  } 

}


function jolley_callback() {
  new jolleyBookingForm();
}
add_action( 'plugins_loaded', 'jolley_callback' ); 
?>