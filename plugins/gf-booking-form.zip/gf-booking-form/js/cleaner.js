// placeholder for javascript
var ajaxurl          = cleanerObj.ajax_url;
var aFormId          = cleanerObj['form_id'];
var aFieldId         = cleanerObj['field_ids'];

var formId           = '#gform_'+aFormId;
var fieldPrefix      = '#input_'+aFormId+'_';
var isFiledPrefix    = '#field_'+aFormId+'_';
var choiseField      = '#choice_'+aFormId+'_';

var fqServiceId      = fieldPrefix + aFieldId['frqOfService'];
var dateTimeId       = fieldPrefix + aFieldId['dateTime'];
var addServiceId     = fieldPrefix + aFieldId['addOnServices'];
var winClnPkgId      = fieldPrefix + aFieldId['winClnPkg'];
var winClnButton     = ".ids-table-scroll tr td button";
var winClnPackage    = ".ids-table-scroll thead th";



function fillSelectField(selector, data){

  var select = jQuery(selector);
  select.removeAttr('disabled');
  select.html('');
  select.html("<option select='selected' value=''>"+emptyMessage+"</option>");

  for(var i=0; i<data.length; i++){
    
    // This kind of array ["response", "response"]
    // boolean, string, integer, float, array, object
    var dataType    = typeof(data[i]);
    var allowedType = ['number', 'string', "boolean"];
    
    if(allowedType.indexOf( dataType ) !== -1){
      jQuery("<option/>",{
        value : data[i]
      }).html(data[i]).appendTo(select);
      continue;
    }

    // Both case key value and Key
    var optionElement = jQuery("<option/>").html(data[i].val);

    // Adding key paramter
    if( typeof(data[i]["key"]) !== 'undefined' ){
      optionElement.attr("value", data[i]["key"]);
    }

    // For loop in javascript ??/
    jQuery.each(data[i], function(key, value){
      if(key === "val" || key === "key"){
        return true; // instead of continue
      }
      optionElement.attr("data-" + key , value);
    });
    // Adding attribute parameter
    optionElement.appendTo(select);
  }
  select.trigger('change');
}

// I have made following function
// So that future changes in API function can be done.

function getApiValue($type){
  switch($type){
    case 'location':
      return jQuery(locatId).val() || 0;
    break;
    case 'currency':
      return jQuery(currencyFieldID).val() || 0;
    break;
  }
  return false;
}

function sendCommonAjax(type,  param){
  
  if(typeof(param['data']) === 'undefined'){
    param['data'] = {};
  }
  param.data = jQuery.extend(param.data, {
    'type'          : type,    
    'action'        : 'ids_ajax_handler',
    'location'      : getApiValue('location'),
    'currency'      : getApiValue('currency'),
  });
  param = jQuery.extend({
    url        : ajaxurl,
    type       : 'POST',
    dataType   : 'json',
    error: function(){
      console.log('Something went wrong while fetching details');
    }
  }, param);

  return jQuery.ajax(param);
}


function getFormatedDate(param){

  if(typeof(param) === "undefined" || param == ""){
    return false;
  }
  var weeks       = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
  var startWeeks  = ["Monday","Tuesday","Wednesday","Thursday","Friday"];
  var months = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];
  // Start Date Calculation
  var date    = new Date(param);
  var day     = date.getDate();  // start date
  var month   = date.getMonth(); // start month
  var year    = date.getFullYear();
  var tDay    = date.getDay();
  var textDay = weeks[tDay];
  return textDay + ", " + day + " " + months[month] + ", " + year;
}

/*
** Update Cart html Function
*/

function updateSummary(value, element, container = false){

  if(container === false){
    container = element;
  }
  if(typeof(value) === 'undefined' || value == "" || value == 0 ){
    jQuery(container).hide();
    return;
  }
  jQuery(element).html(value);  
  jQuery(container).show();

}

function upExFiledId(value, element){
  jQuery(element).val(value).change();
}


function updateBulkSummary(summaryObj, htmlElement, dValue ){

  if(htmlElement === undefined) {
   htmlElement = false;
  }
  if(dValue === undefined) {
    dValue = {};
  }


  jQuery.each(summaryObj, function(field, obj){

    // Get Value
    if(typeof(dValue[field]) !== 'undefined'){
      value = dValue[field];
    }else if(htmlElement !== false){
      value = jQuery('option:selected', htmlElement ).attr("data-"+field) || "";
    }else{
      value = "";
    }
    
    /*if(typeof(value == 'undefined') || value == 0 ){
      return;
    }*/
    // Update Summary

    if(typeof(obj.summary) !== 'undefined'){
      var summary = obj.summary;
      if(summary.length == 2){
        updateSummary(value  , summary[0], summary[1]);
      }else{
        updateSummary(value  , summary[0]);
      } 
    }
    // Update Hidden field
    if(typeof(obj.field) !== 'undefined'){
      upExFiledId(value  ,  obj.field);
    }
  });   
}

jQuery(document).ready(function(){

  jQuery(fqServiceId).on( "click", function() {
    var name = jQuery( "input:checked" ).val();
    if(typeof(name) === "undefined" || name === ""){
      updateSummary("" , "p.descr__gray");
      return;
    }
    updateSummary(name , "p.descr__gray");
  });

  jQuery(dateTimeId).change(function() {
    var name     = jQuery(this).val();
    var dateTime = getFormatedDate(name);
    if(typeof(name) === "undefined" || name === ""){
      updateSummary("" , "p.descr__gray");
      return;
    }
    updateSummary(dateTime , "p.descr__gray");
  
  });


  jQuery(winClnButton).on( "click", function() {
    var index    = jQuery(winClnButton).index(this);
    var newIndex = parseInt(index) + 1;
    var title    = jQuery(winClnPackage + ':eq('+newIndex+')').text();
    var name     = jQuery(winClnPkgId).val(title);
    console.log(name);
    

    if(typeof(name) === "undefined" || name === ""){
      updateSummary("" , "p.descr__gray");
      return;
    }
    updateSummary(name , "p.descr__gray");
  });


  jQuery(addServiceId).on( "click", function() {
    
    var name = [];
    jQuery(':checkbox:checked').each(function(i){
      name[i] = jQuery(this).val();
    });

    //cndSunScr-cont

    if(typeof(name) === "undefined" || name === ""){
      updateSummary("" , "p.descr__gray");
      return;
    }
    updateSummary(name , "p.descr__gray");
  });
});