// Single delete

jQuery(document).ready(function(){

	var headname = jQuery('.wp-heading-inline').text().trim();



	// Multi Delete

	jQuery('#doaction').click(function(){

		var bulkAction = [];

			jQuery.each(jQuery("#bulk-action-selector-top option:selected"), function(){            

			bulkAction.push(jQuery(this).val());

		});

		if( jQuery('.checkItem:checked').length == '' ){

			alert('Please select atleast one checkbox');

			return false;

		}  

		if(confirm("Do you want to delete this "+headname+" ?")){

			return true;

		}                      

		return false;

	});



	// Single Delete

  jQuery('.deleteAction').click(function(){

		var href = jQuery(this).attr('href');

		if(confirm("Do you want to delete this "+headname+"")){

			location.replace(href);

		}

		return false;

	});

});