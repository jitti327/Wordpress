
jQuery(document).ready(function(){
   jQuery(".gf-window .ids-right").stick_in_parent({
   offset_top: 0,
  });
});
