<table class="table1">

  <thead>

    <tr>

      <th></th>

      <?php 

        $metaData = [];

        foreach ($array['packages'][0] as $packageName) {

          $query      = "SELECT * FROM $metaPO WHERE `package_id`=".$packageName->id;

          $metaData[] = $wpdb->get_results($query);

          echo '<th scope="col" abbr="Starter">'.$packageName->package_name.'</th>';  

        }

      ?>

    </tr>

  </thead>

  <tfoot>

    <tr>

        <th scope="row" style="border: 0px;"></th>

        <td><button type="button">Select</button></td>

        <td><button type="button">Select</button></td>

        <td><button type="button">Select</button></td>

    </tr>

  </tfoot>

  <tbody>

    <?php 

      foreach ($array['options'][0] as $optionField) { 

    ?>

        <tr>

          <th scope="row"><?php echo $optionField->package_option_name; ?></th>

          <?php

            foreach ($metaData as $pOptions) {

              $text  = [];

              foreach ($pOptions as $checkedValue) {

                $text[$checkedValue->package_option_id] = $checkedValue->package_option_key;

              }
              
             $textArray = !empty($text[$optionField->id])  ? $text[$optionField->id] : false;

              if( $textArray == 'yes'){

                echo '<td><span class="check"></span></td>';

              }else{

                echo '<td>'.$textArray.'</td>';

              }

            }

          ?>



        </tr>

    <?php

      }

    ?>

  </tbody>

</table>