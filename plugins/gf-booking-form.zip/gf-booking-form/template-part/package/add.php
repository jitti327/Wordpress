<?php
try{
  if(isset($_POST['add'])){
    $data = [
      'package_name' => $_POST['package_name'] 
    ];
    $success = insertPackage($tableName,$data);
    if($success === false){
      throw new Exception('Sorry unable to save Package !! Try again.');
    }
    message_notification("updated","The package has been Saved successfully");
  }
}catch(Exception $e){
  message_notification('error',$e->getMessage());
}
?>
<form method="post">
  <h2>Add New Package</h2>
  <?php  
    settings_errors('settings-page-slug');
    do_settings_sections( 'my-setting-admin' ); 
    submit_button('Save','primary','add');
  ?>
</form>