<?php

  /** *************************** RENDER TEST PAGE ********************************
   *******************************************************************************
   * This function renders the admin page and the example list table. Although it's
   * possible to call prepare_items() and display() from the constructor, there
   * are often times where you may need to include logic here between those steps,
   * so we've instead called those methods explicitly. It keeps things flexible, and
   * it's the way the list tables are used in the WordPress core.
   */

  //Create an instance of our package class...
  $testListTable = new packages_table();
  //Fetch, prepare, sort, and filter our data...
  $testListTable->prepare_items();
  ?>
<div class="wrap">    
  <div id="icon-users" class="icon32"><br/></div>
    <h1 class="wp-heading-inline">
      Packages
    </h1>
    <a href="<?php echo admin_url('admin.php?page=add-package','admin'); ?>&amp;action=add" class="page-title-action">Add New</a> 
    <hr class="wp-header-end">
    <?php settings_errors('settings-page-slug'); ?>
  <form method="get" action="">
    <input type="hidden" name="page" value="<?php echo $_GET['page']; ?>"/>
    <?php $testListTable->search_box( 'search', 'search_id' ); ?>
  </form>     
  
   <form method="post" action="">
    <?php $testListTable->display(); ?> 
  </form>   
</div>