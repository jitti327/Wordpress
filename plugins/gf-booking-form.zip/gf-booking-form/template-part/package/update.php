<?php
try{
  if(isset($_POST['update'])){  
  
    # update the package name
    $data = [
      'package_name' => $_POST['package_name'] 
    ];

    $packageOption = isset($_REQUEST['package_option_name']) ? $_REQUEST['package_option_name'] : [];
    $packageO_KEY   = isset($_REQUEST['package_option_key']) ? $_REQUEST['package_option_key'] : [];

    $success = updatePackage($packageTable,$data,array('id'=>$_REQUEST['post'])); 
    if($success === false){
      throw new Exception('Sorry unable to save Package !! Try again.');
    } 

    # all the delete of selected package options using packageId
    $countP_id  = countRecord($metaPO , "`package_id` = ".$_REQUEST['post']);
    if($countP_id !== 0 ){
      $delete = DeleteAction( $metaPO , array('package_id' => $_REQUEST['post']) );
      if($delete == false){
        throw new Exception('Sorry unable to update Package options !! Try again.');
      }
    }      

    # insert the selected package option using packageId
    foreach ($packageOption as $PO_id) {
      $metadata = [
        'package_id'        => $_REQUEST['post'],
        'package_option_id' => $PO_id,
        'package_option_key'=> 'yes'
      ];

      $insertPO = insertPackage($metaPO,$metadata);
      if($insertPO === false){
        throw new Exception('Sorry unable to save Package options !! Try again.');
      }
    }

    # insert the selected package option using packageId
    foreach ($packageO_KEY as $PO_id => $optionKey ) {
      $metadata = [
        'package_id'        => $_REQUEST['post'],
        'package_option_id' => $PO_id,
        'package_option_key'=> $optionKey
      ];
      $insertPO = insertPackage($metaPO,$metadata);
      if($insertPO === false){
        throw new Exception('Sorry unable to save Package options !! Try again.');
      }
    }

    message_notification("updated","The package has been saved successfully");
  }
}catch(Exception $e){
  message_notification('error',$e->getMessage());
}
?>
<form method="post">
  <h2>Update Package</h2>
  <?php  
    settings_errors('settings-page-slug');
    do_settings_sections( 'package-update' ); 
    submit_button('Save Change','primary','update');
  ?>
</form>