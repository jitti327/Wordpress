<?php
try{
  if(isset($_POST['add'])){
    $data = [
      'package_option_name' => $_POST['package_name'],
      'type'                => $_POST['type']
    ];
    $success = insertPackage($tableName,$data);
    if($success === false){
      throw new Exception('Sorry unable to save package options !! Try again.');
    }
    message_notification("updated","Package option has been saved");
  }
}catch(Exception $e){
  message_notification('error',$e->getMessage());
}
?>
<form method="post">
  <h2>Add Package options</h2>
  <?php  
    settings_errors('settings-page-slug');
    do_settings_sections( 'package-option-setting' ); 
    submit_button('Save','primary','add');
  ?>
</form>