<?php
try{

  if(isset($_POST['update'])){  

    # update the package name
    $data = [
      'package_option_name' => $_POST['package_name'],
      'type'                => $_POST['type']
    ];
   
    $success = updatePackage($packageOption,$data,array('id'=>$_REQUEST['post'])); 
    if($success === false){
      throw new Exception('Sorry unable to save package option !! Try again.');
    } 
    message_notification("updated","The package option has been saved successfully");
  }
}catch(Exception $e){
  message_notification('error',$e->getMessage());
}
?>
<form method="post">
  <h2>Update Package Options</h2>
  <?php  
    settings_errors('settings-page-slug');
    do_settings_sections( 'package-option-setting' ); 
    submit_button('Save Change','primary','update');
  ?>
</form>