function map_form(){ 
               
              if(document.getElementById("form_files").value=="")
              {
               document.getElementById("form_err").style.display="block";
              }
               
              if(document.getElementById("docx_files").value=="")
              {
               document.getElementById("docx_err").style.display="block";
              }
               
              
              }