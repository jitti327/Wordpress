jQuery(document).ready(
                       function()
                       {
                            alert("Your request has been sent successfully. You will be contacted soon, once your password is reset.");
                       }
                      );